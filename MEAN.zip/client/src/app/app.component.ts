import { Component } from '@angular/core';

import { MarvellousService } from './marvellous.service';
import { OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  
  providers: [MarvellousService],
})                                                        // OnInit  is called as lifecycle hook (stages of function in life of component)
export class AppComponent implements OnInit {
  
  message : any;

  constructor(private Service : MarvellousService )
  {}
  ngOnInit()                            // callback method i.e it gets called when component gets rendered
  {
    this.Service.getBatches().subscribe(data=>{
      this.message = data;
    })
  }
}

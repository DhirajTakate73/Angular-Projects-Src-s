import { ElementRef, HostListener, Host, Directive } from '@angular/core';

@Directive
({
  selector: '[appMarvellous]',      // hey nav project madhye vaprav lagnar ahe nantar kuthetari
  standalone: true          // nantar konalapaan deu shaktat
})
export class MarvellousDirective 
{

  constructor(private obj: ElementRef) // parameterises constructor beacause it is taking paramenters(ElementRef obj gets inserted into the constructor of directives class   i.e Dependency Injection)
  {}
    @HostListener('mouseenter') onmouseenter()    // cursor aala ki kay 
  {             // Method cha handle      // mwthod ch nav
    this.obj.nativeElement.style.background = 'cyan';
  }

  @HostListener('mouseleave') onmouseleave()      // cursor gela ki kay 
  {
    this.obj.nativeElement.style.background = 'violet';
  }                       // style badla element cha background change kara
                          // shadow, font, colour sagla badlu shakto 
  }

  // HostListener = mouse hallla ki nahi te sangnyasathi zalelea badal kalav
  // ElementRef = colour badalnyasathi



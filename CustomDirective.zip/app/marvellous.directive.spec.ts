import { MarvellousDirective } from './marvellous.directive';

describe('MarvellousDirective', () => {
  it('should create an instance', () => {
    const directive = new MarvellousDirective();
    expect(directive).toBeTruthy();
  });
});

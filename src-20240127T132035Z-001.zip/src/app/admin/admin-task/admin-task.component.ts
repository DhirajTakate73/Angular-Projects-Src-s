import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-task',
  templateUrl: './admin-task.component.html',
  styleUrl: './admin-task.component.css'
})
export class AdminTaskComponent {

}

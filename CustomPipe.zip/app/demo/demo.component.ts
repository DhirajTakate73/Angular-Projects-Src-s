import { Component } from '@angular/core';
import { CustompipePipe } from '../custompipe.pipe';

@Component({
  selector: 'app-demo',
  standalone: true,
  imports: [CustompipePipe],
  templateUrl: './demo.component.html',
  styleUrl: './demo.component.css'
})
export class DemoComponent {

}

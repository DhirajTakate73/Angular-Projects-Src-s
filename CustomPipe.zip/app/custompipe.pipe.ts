import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe',
  standalone: true
})
export class CustompipePipe implements PipeTransform 
{

  transform(value: unknown, ...args: unknown[]): unknown 
  {
    console.log("Inside transform method...");
    
    if(args[0] == "PPA")
    {
      return "pre-placement activity";
    }

    if(args[0] == "Angular")
    {
      return "angular with MEAN stack";
    }

    return null;
  }

}

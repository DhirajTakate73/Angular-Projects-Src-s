import { Injectable } from '@angular/core';   // inject hou shaknara

@Injectable
({
  providedIn: 'root'      // root madhye inject hoil
})
export class MarvellousService    // userdefined service
{
  constructor() { }

  getbatches()
  {
    return [
      {"name" : "pre placement activity", "duration" : "3 months", "fees" : 19500},
      {"name" : "logic building", "duration" : "3.5 months", "fees" : 20000},
      {"name" : "python machine learning", "duration" : "4 months", "fees" : 20500},
      {"name" : "web development", "duration" : "4.5 months", "fees" : 21500},
    ];
  }
}

express = require('express');           // imports sarkha

eobj = express();                       // express module cha object tyar kela

port = 5100;                           // jya port no. varun chalu karaycha tyacha no.

function starter()
{
    console.log("Marvellous server is listening at port "+port);
}

eobj.listen(port, starter);
                  // server listening mode madhye chalu hoyla pahije tyasathi method                               


function AcceptRequest(req,res)
{
    res.send("Marvellous server is ON....");
}

eobj.get('/',AcceptRequest);
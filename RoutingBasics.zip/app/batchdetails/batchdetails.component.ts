import { Component } from '@angular/core';

@Component({
  selector: 'app-batchdetails',
  standalone: true,
  imports: [],
  templateUrl: './batchdetails.component.html',
  styleUrl: './batchdetails.component.css'
})
export class BatchdetailsComponent {

}

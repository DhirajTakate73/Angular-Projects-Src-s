import { Routes } from '@angular/router';
import { BatchdetailsComponent } from './batchdetails/batchdetails.component';
import { BatchlistComponent } from './batchlist/batchlist.component';
import { HomePageComponent } from './home-page/home-page.component';
import { InvalidpageComponent } from './invalidpage/invalidpage.component';

export const routes: Routes = [
// Specific route
{path : 'batchdetails', component : BatchdetailsComponent},
{path : 'batchlist', component : BatchlistComponent},

// default route
{path : '', component : HomePageComponent},                 // url madhye 4200 chya pudhe kahi dil nasel tar homepage works lihun yeil so it is default route

// wildcard route  / inavalid route                        // url madhye 4200 chya pudhe kahipaan invalid takla ki jyacha route aaplyakade nahi ye tar invLISPg works asa lihun yeil so it is wildcard route/ invalidpageroute 
{path : '**', component : InvalidpageComponent},


];

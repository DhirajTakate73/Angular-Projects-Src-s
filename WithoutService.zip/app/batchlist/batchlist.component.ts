import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';       // #

@Component({
  selector: 'app-batchlist',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './batchlist.component.html',
  styleUrl: './batchlist.component.css'
})
export class BatchlistComponent 
{
  public batches = 
  [
    {"name" : "pre placement activity", "duration" :"3 months" ,"fees" :"19500"},
    {"name" : "logic building", "duration" :"3.5 months" ,"fees" : "20500"},
    {"name" : "python machine learning", "duration" :"4 months" ,"fees" : "21000"},
    {"name" : "angular with mean", "duration" :"4.5 months" ,"fees" : "22000"},
    // json foramt  key  :   value format

  ];
}
